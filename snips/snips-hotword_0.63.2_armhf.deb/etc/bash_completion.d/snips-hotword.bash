_snips-hotword() {
    local i cur prev opts cmds
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    cmd=""
    opts=""

    for i in ${COMP_WORDS[@]}
    do
        case "${i}" in
            snips-hotword)
                cmd="snips-hotword"
                ;;
            
            capture)
                cmd+="__capture"
                ;;
            file)
                cmd+="__file"
                ;;
            help)
                cmd+="__help"
                ;;
            *)
                ;;
        esac
    done

    case "${cmd}" in
        snips-hotword)
            opts=" -v -h -V -t -c -a -u  --no_vad_inhibitor --vad_messages --verbose --color --no-color --mqtt-tls-disable-root-store --help --version --sensitivity --hotword-id --model --config --bus --mqtt --mqtt-username --mqtt-password --mqtt-tls-hostname --mqtt-tls-cafile --mqtt-tls-capath --mqtt-tls-client-cert --mqtt-tls-client-key --audio --assistant --user-dir   capture file help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 1 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                
                --sensitivity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -t)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --hotword-id)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --model)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --config)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -c)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --bus)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-username)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-password)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-hostname)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-cafile)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-capath)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-client-cert)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-client-key)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --audio)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --assistant)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -a)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --user-dir)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -u)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        
        snips__hotword__capture)
            opts=" -h -V  --help --version  "
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        snips__hotword__file)
            opts=" -h -V  --confidences --help --version --loops  <WAV_FILE>... "
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                
                --loops)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        snips__hotword__help)
            opts=" -h -V  --help --version  "
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
    esac
}

complete -F _snips-hotword -o bashdefault -o default snips-hotword
