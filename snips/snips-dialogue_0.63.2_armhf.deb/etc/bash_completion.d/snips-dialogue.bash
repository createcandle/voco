_snips-dialogue() {
    local i cur prev opts cmds
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    cmd=""
    opts=""

    for i in ${COMP_WORDS[@]}
    do
        case "${i}" in
            snips-dialogue)
                cmd="snips-dialogue"
                ;;
            
            *)
                ;;
        esac
    done

    case "${cmd}" in
        snips-dialogue)
            opts=" -v -h -V -c -a -u  --sound-feedback-disabled-default --verbose --color --no-color --mqtt-tls-disable-root-store --help --version --resources --default-site-id --session-timeout --lambda-timeout --retry-count --config --assistant --user-dir --bus --mqtt --mqtt-username --mqtt-password --mqtt-tls-hostname --mqtt-tls-cafile --mqtt-tls-capath --mqtt-tls-client-cert --mqtt-tls-client-key  "
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 1 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                
                --resources)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --default-site-id)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --session-timeout)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --lambda-timeout)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --retry-count)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --config)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -c)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --assistant)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -a)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --user-dir)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -u)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --bus)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-username)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-password)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-hostname)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-cafile)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-capath)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-client-cert)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-client-key)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        
    esac
}

complete -F _snips-dialogue -o bashdefault -o default snips-dialogue
