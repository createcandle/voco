_snips-tts() {
    local i cur prev opts cmds
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    cmd=""
    opts=""

    for i in ${COMP_WORDS[@]}
    do
        case "${i}" in
            snips-tts)
                cmd="snips-tts"
                ;;
            
            *)
                ;;
        esac
    done

    case "${cmd}" in
        snips-tts)
            opts=" -v -h -V -p -c -a -u  --verbose --color --no-color --mqtt-tls-disable-root-store --help --version --provider --custom-command --config --bus --mqtt --mqtt-username --mqtt-password --mqtt-tls-hostname --mqtt-tls-cafile --mqtt-tls-capath --mqtt-tls-client-cert --mqtt-tls-client-key --assistant --user-dir  "
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 1 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                
                --provider)
                    COMPREPLY=($(compgen -W "PicoTts MacosTts MakersTts CustomTts" -- "${cur}"))
                    return 0
                    ;;
                    -p)
                    COMPREPLY=($(compgen -W "PicoTts MacosTts MakersTts CustomTts" -- "${cur}"))
                    return 0
                    ;;
                --custom-command)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --config)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -c)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --bus)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-username)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-password)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-hostname)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-cafile)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-capath)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-client-cert)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-client-key)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --assistant)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -a)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --user-dir)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -u)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        
    esac
}

complete -F _snips-tts -o bashdefault -o default snips-tts
